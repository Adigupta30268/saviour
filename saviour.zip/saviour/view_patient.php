<?php
// Replace these variables with your database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Get all tables in the database
$tables_query = mysqli_query($conn, "SHOW TABLES");
$tables = mysqli_fetch_all($tables_query, MYSQLI_ASSOC);

// Loop through all tables
foreach ($tables as $table) {
  $table_name = $table['Tables_in_' . $dbname];
  
  // Get specified data from each table
  $data_query = mysqli_query($conn, "SELECT Full_Name,Email,DOB,Phone_Number FROM `$table_name` WHERE id=1");
  $data = mysqli_fetch_all($data_query, MYSQLI_ASSOC);

  // Display table name and data in a tabular form
 
}

mysqli_close($conn);
?>

<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <style>
      #id{
        background-color : white;
        width:300px;
      }
      #ih{
        background-color : linear-gradient(rgba(132, 250, 176, 1), rgba(143, 211, 244, 1));
      }
    </style>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body >

  <div class="container mt-5 px-2">
    
    <div class="mb-2 d-flex justify-content-between align-items-center">
        <form action="view_records.php">
        <div class="position-relative" style="display:flex">
            <span class="position-absolute search" ><i class="fa fa-search"></i></span>
            <input name="entryID" type="text" class="form-control w-100" placeholder="Search by order#, name...">
            <button type="submit" class="btn btn-warning" id="id">View Record</button>
        </div>
        </form>
        
        <div class="px-2">
            
            <span>Filters <i class="fa fa-angle-down"></i></span>
            <i class="fa fa-ellipsis-h ms-3"></i>
        </div>
        
    </div>
    <div class="table-responsive">
    <table class="table table-responsive table-borderless">
        
      <thead>
        <tr class="bg-light">
          <th scope="col" width="5%">#</th>
          <!--<th scope="col" width="20%">Image</th>-->
          <th scope="col" width="10%">Full Name</th>
          <th scope="col" width="20%">E-mail</th>
          <th scope="col"  width="20%">Contact No.</th>
          <th scope="col"  width="20%">Date of Birth</th>
        </tr>
      </thead>
  <tbody>
      
  <?php
        foreach ($data as $row) {
            echo "<tr id=ih><td>" . $table_name . "</td><td>" . $row['Full_Name'] . "</td><td>" . $row['Email'] . "</td><td>" . $row['DOB'] . "</td><td>" . $row['Phone_Number'] . "</td></tr>";
          }
        ?>
   
  </tbody>
</table>
  
  </div>
    
</div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
