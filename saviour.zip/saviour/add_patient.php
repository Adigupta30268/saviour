<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'test';

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

if(isset($_POST['submit'])){
    $table_name = mysqli_real_escape_string($conn, $_POST['table_name']);
    $full_name=mysqli_real_escape_string($conn,$_POST['full_name']);
    $email=mysqli_real_escape_string($conn,$_POST['email']);
    $num=mysqli_real_escape_string($conn,$_POST['num']);
    $dob=mysqli_real_escape_string($conn,$_POST['dob']);

   
    $sql = "CREATE TABLE `$table_name` (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        Full_Name VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
        Email VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
        Phone_Number VARCHAR(100) NOT NULL,
        DOB DATE NOT NULL,
        image_path VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci  NULL,
        pdf_path VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci  NULL,
        symptom TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci  NULL,
        advice TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci  NULL,
        ttm TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci  NULL,
        hosptal_clinic VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL

        
    )";
   
   mysqli_query($conn, $sql);
    
   $sql1 = "INSERT INTO `$table_name` (Full_Name, Email, Phone_Number, DOB) VALUES ('$full_name', '$email', '$num', '$dob')";

    
    if (mysqli_query($conn, $sql1)) {
         echo "Table created successfully";
    } else {
        echo "Error creating table: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>

<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <style>
        .gradient-custom-3 {
/* fallback for old browsers */
background: #84fab0;

/* Chrome 10-25, Safari 5.1-6 */
background: -webkit-linear-gradient(to right, rgba(132, 250, 176, 0.5), rgba(143, 211, 244, 0.5));

/* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
background: linear-gradient(to right, rgba(132, 250, 176, 0.5), rgba(143, 211, 244, 0.5))
}
.gradient-custom-4 {
/* fallback for old browsers */
background: #84fab0;

/* Chrome 10-25, Safari 5.1-6 */
background: -webkit-linear-gradient(to right, rgba(132, 250, 176, 1), rgba(143, 211, 244, 1));

/* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
background: linear-gradient(to right, rgba(132, 250, 176, 1), rgba(143, 211, 244, 1))
}
    </style>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
    <section class="vh-100 bg-image"
    style="background-image: url('https://mdbcdn.b-cdn.net/img/Photos/new-templates/search-box/img4.webp');">
    <div class="mask d-flex align-items-center h-100 gradient-custom-3">
      <div class="container h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
          <div class="col-12 col-md-9 col-lg-7 col-xl-6">
            <div class="card" style="border-radius: 15px;">
              <div class="card-body p-5">
                <h2 class="text-uppercase text-center mb-5">Add Patient</h2>

         <form class="well form-horizontal"  method="post" enctype="multipart/form-data" id="contact_form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" >
                   
         <div class="form-group">
                        <label class="col-md-4 control-label">Enter ID</label>  
                        <div class="col-md-4 inputGroupContainer">
                        <div class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        <input  name="table_name" placeholder="As per Aadhar Card" class="form-control"  type="text" required>
                          </div>
                        </div>
                      </div>

         <div class="form-group">
                        <label class="col-md-4 control-label">Full Name</label>  
                        <div class="col-md-4 inputGroupContainer">
                        <div class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        <input  name="full_name" placeholder="As per Aadhar Card" class="form-control"  type="text" required>
                          </div>
                        </div>
                      </div>
                    
                      <div class="form-group">
      <label class="col-md-4 control-label">E-Mail</label>  
        <div class="col-md-4 inputGroupContainer">
        <div class="input-group">
            <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
      <input name="email" placeholder="E-Mail Address" class="form-control"  type="text" required>
        </div>
      </div>
    </div>
    
    
    <!-- Text input-->
           
    <div class="form-group">
      <label class="col-md-4 control-label">Contact No.</label>  
        <div class="col-md-4 inputGroupContainer">
        <div class="input-group">
            <span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span>
      <input name="num" placeholder="8975423457" class="form-control" type="number" required>
        </div>
      </div>
    </div>

    <div class="form-group">
      <label class="col-md-4 control-label">Date of Birth</label>  
        <div class="col-md-4 inputGroupContainer">
        <div class="input-group">
            <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
      <input name="dob" placeholder="11-10-2004" class="form-control" type="date" required>
        </div>
      </div>
    </div>
  
                 
                  <div class="d-flex justify-content-center">
                    <button type="submit" name="submit" value="Submit"
                      class="btn btn-success btn-block btn-lg gradient-custom-4 text-body"
                      style="background: linear-gradient(rgba(132, 250, 176, 1), rgba(143, 211, 244, 1));" >Register</button>
                  </div>
  
                  <p class="text-center text-muted mt-5 mb-0">Have already an account? <a href="#!"
                      class="fw-bold text-body"><u>Login here</u></a></p>
  
                </form>
  
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>