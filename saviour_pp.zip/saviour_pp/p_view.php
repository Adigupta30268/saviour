<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "patient");

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user has submitted the form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the user ID from the form
    $id = $_POST["id"];

    // Query the database to get user data
    $sql = "SELECT * FROM entries WHERE ID = $id";
    $result = $conn->query($sql);
    echo"
    <div class=table-responsive>
    <table class=table table-responsive table-borderless>
         <thead>
         <tr>
         <th width=300px margin=50px>#</th>
         <th width=auto margin=50px>DETAILS</th>
         </tr>
         <tbody>";
    // Check if the query was successful
    if ($result->num_rows > 0) {
        // User data found, display it on the page
        while ($row = $result->fetch_assoc()) {
            foreach ($row as $column => $value) {
                if ($column == 'Prescription') { // Replace 'image_url' with your actual image column name
                  echo "<tr padding=100px><td>$column <b>:</b> </td><td><img src=./image/{$value} height=100px width=100px onclick=zoomImage(this)></td></tr>";
                  echo "<img id=zoomedImage src=./image/{$value}>";
              } else {
                  echo "<tr><td>$column <b>:</b> </td><td> $value</td></tr>";
              }
              
          }
            // Add any other fields you want to display
        }
        echo"</tbody>
        </div>";
    } else {
        // No user data found, display an error message
        echo "No user found with ID " . $id;
    }
}
?>

<!DOCTYPE html>
<html>
    <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
    #zoomedImage {
      position: absolute;
      z-index: 9999;
      display: none;
    }
    </style>
        </head>
        <body>
<form method="post">
    <label for="id">Enter your ID:</label>
    <input type="text" name="id" id="id">
    <input type="submit" value="Submit">
</form>

<script>
    function zoomImage(img) {
      var zoomedImage = document.getElementById("zoomedImage");
      zoomedImage.src = img.src;
      zoomedImage.style.display = "block";
      zoomedImage.style.top = img.offsetTop + "px";
      zoomedImage.style.left = img.offsetLeft + img.offsetWidth + "px";
    }
    
    document.getElementById("zoomedImage").onclick = function() {
      this.style.display = "none";
    };
  </script>
  </body>
</html>