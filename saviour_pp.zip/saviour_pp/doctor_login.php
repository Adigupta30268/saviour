<?php

// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "doctors";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

if(isset($_POST['submit'])){
    
    $id = $_POST['id'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM `" . $id . "` WHERE Passwordd = '" . $password . "'";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
	// User exists and password is correct
	    $conn->close();
	    header("Location: view2.php"); // Redirect to success page
	    exit();
    } else {
	// User does not exist or password is incorrect
	    echo "Invalid ID or password.";
	    $conn->close();
    }
}


?>

<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
    <style>
    .gradient-custom-3 {
/* fallback for old browsers */
background: lightgrey;

/* Chrome 10-25, Safari 5.1-6 */
background: -webkit-linear-gradient(to right, lightgrey, lightgrey);

/* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
background: linear-gradient(to right)
}
.gradient-custom-4 {
/* fallback for old browsers */
background: #84fab0;

/* Chrome 10-25, Safari 5.1-6 */
background: -webkit-linear-gradient(to right);

/* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
background: linear-gradient(to right, rgba(132, 250, 176, 1), rgba(143, 211, 244, 1))
}
</style>
<link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
</head>
<body>
	
    <section class="vh-100 bg-image"
  style="background-image: url('https://mdbcdn.b-cdn.net/img/Photos/new-templates/search-box/img4.webp');">
  <div class="mask d-flex align-items-center h-100 gradient-custom-3">
    <div class="container h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-12 col-md-9 col-lg-7 col-xl-6">
          <div class="card" style="border-radius: 15px;">
            <div class="card-body p-5">
                <div display="flex">
                <img src="logo.jpg" height="70px" width="70px">
              <h2 class="text-uppercase text-center mb-5" style="margin-top:0px;">Welcome to Saviour login</h2>
</div>
<form method="post"  action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

<div class="form-outline mb-4">Enter Your Medical ID :
    <input type="text" name="id" id="form3Example1cg" class="form-control form-control-lg" />
  </div>

  <div class="form-outline mb-4">Password :
    <input type="password" name="password" id="form3Example4cdg" class="form-control form-control-lg" />
  </div>

  <div class="d-flex justify-content-center">
    <button type="submit"
      class="btn btn-success btn-block btn-lg gradient-custom-4 text-body" name="submit">Submit</button>
  </div>
  </form>
  </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
</body>
</html>

