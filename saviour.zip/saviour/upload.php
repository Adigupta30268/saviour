<?php
// Define database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the form is submitted
if(isset($_POST['submit'])) {

    // Get the uploaded files
    $table_name =  mysqli_real_escape_string($conn, $_POST['table_name']);
    $image = $_FILES['image']['tmp_name'];
    $pdf = $_FILES['pdf']['tmp_name'];
    $symp =  mysqli_real_escape_string($conn, $_POST['symp']);
    $advice =  mysqli_real_escape_string($conn, $_POST['adv']);
    $clinic_hospital =  mysqli_real_escape_string($conn, $_POST['c_h']);
    $ttm = mysqli_real_escape_string($conn,$_POST['ttm']);


    // Define the target directory for the files
    $image_target_dir = "uploads/images/";
    $pdf_target_dir = "uploads/pdfs/";

    // Get the file names
    $image_name = basename($_FILES["image"]["name"]);
    $pdf_name = basename($_FILES["pdf"]["name"]);

    // Define the target paths for the files
    $image_target_path = $image_target_dir . $image_name;
    $pdf_target_path = $pdf_target_dir . $pdf_name;

    // Upload the files to the target directories
    move_uploaded_file($image, $image_target_path);
    move_uploaded_file($pdf, $pdf_target_path);

    // Insert the file names and paths into the database
    $sql = "INSERT INTO `$table_name` (image_path,pdf_path,symptom,advice,ttm,hosptal_clinic) VALUES ('$image_target_path','$pdf_target_path','$symp','$advice','$ttm','$clinic_hospital')";

    if (mysqli_query($conn, $sql)) {
        echo "Files uploaded and inserted into database successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}

// Close database connection
mysqli_close($conn);
?>
<!DOCTYPE html>
<head>
    <title>
        Upload
</title>
<style>
    .gradient-custom-3 {
/* fallback for old browsers */
background: #84fab0;

/* Chrome 10-25, Safari 5.1-6 */
background: -webkit-linear-gradient(to right, rgba(132, 250, 176, 0.5), rgba(143, 211, 244, 0.5));

/* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
background: linear-gradient(to right, rgba(132, 250, 176, 0.5), rgba(143, 211, 244, 0.5))
}
.gradient-custom-4 {
/* fallback for old browsers */
background: #84fab0;

/* Chrome 10-25, Safari 5.1-6 */
background: -webkit-linear-gradient(to right, rgba(132, 250, 176, 1), rgba(143, 211, 244, 1));

/* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
background: linear-gradient(to right, rgba(132, 250, 176, 1), rgba(143, 211, 244, 1))
}
</style>
<link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
</head>
<body>

<section class="vh-100 bg-image"
  style="background-image: url('https://mdbcdn.b-cdn.net/img/Photos/new-templates/search-box/img4.webp');">
  <div class="mask d-flex align-items-center h-100 gradient-custom-3">
    <div class="container h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-12 col-md-9 col-lg-7 col-xl-6">
          <div class="card" style="border-radius: 15px;">
            <div class="card-body p-5">
              <h2 class="text-uppercase text-center mb-5">Be up-to-date with your Patient's Data</h2>

              <form method="post" enctype="multipart/form-data"  action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

              <div class="form-outline mb-4">Enter Patient ID :
                  <input type="text" name="table_name" id="form3Example1cg" class="form-control form-control-lg" />
                </div>

                <div class="form-outline mb-4">Upload Image :
                  <input type="file" name="image" id="form3Example1cg" class="form-control form-control-lg" />
                </div>

                <div class="form-outline mb-4">Upload PDF :
                  <input type="file" name="pdf" id="form3Example3cg" class="form-control form-control-lg" />
                </div>

                <div class="form-outline mb-4">Symptom :
                  <input type="text" name="symp" id="form3Example4cg" class="form-control form-control-lg" />
                </div>

                <div class="form-outline mb-4">Advice :
                  <input type="text" name="adv" id="form3Example4cdg" class="form-control form-control-lg" />
                </div>

                <div class="form-outline mb-4">Treatment :
                  <input type="text" name="ttm" id="form3Example4cdg" class="form-control form-control-lg" />
                </div>

                <div class="form-outline mb-4">Name of hospital/clinic :
                  <input type="text" name="c_h" id="form3Example4cdg" class="form-control form-control-lg" />
                </div>

                <div class="form-check d-flex justify-content-center mb-5">
                  <input class="form-check-input me-2" type="checkbox" value="" id="form2Example3cg" />
                  <label class="form-check-label" for="form2Example3g">
                    I agree all statements in <a href="#!" class="text-body"><u>Terms of service</u></a>
                  </label>
                </div>

                <div class="d-flex justify-content-center">
                  <button type="submit"
                    class="btn btn-success btn-block btn-lg gradient-custom-4 text-body" name="submit">Update</button>
                </div>

              </form>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

                </body>